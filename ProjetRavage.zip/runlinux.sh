echo "Lancement du jeu ProjetRavabe !!!!"
java -Xmx256m -cp ./lib/jsfml.jar:./lib/jbox2d-library.jar:./lib/jdom-2.0.5.jar:./lib/javax.json-1.0.2.jar:./lib/slick.jar:bin/ ravage.MainProgram
echo ProjetRavage !!!!"terminé!"



